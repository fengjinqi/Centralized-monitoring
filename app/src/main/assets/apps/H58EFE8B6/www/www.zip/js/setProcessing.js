var objData;
objData={}
var fd;
fd = new FormData();
var vm=new Vue({
        el:"#root",
        data:{
            guid:'',
            validate:'validate',
            author:'zxgd',
            validaTetable:'validaTetable',
            items:[],
            fj:'',
            fieIdCode:'',
            task:[],
            field:'',
            id:'',
            taskid:'',
            performer:[],
            select:'',
            getLogin:'',
            claim:null,

        },
        methods:{
            gettask:function(){
                var obj={}
                var _this=this
                obj.taskId=String(this.taskid)
                obj.creator=String(this.getLogin)
                plus.nativeUI.showWaiting( '正在加载' )
                mui.ajax("http://127.0.0.1:10261/itsm/rest/api/v2/itsm/tickets/claim",{
                            dataType:'json',
                            type:'post',
                            data:JSON.stringify(obj),
                            success:function(res){
                                if(res.success==true){
                                     _this.claim=false

                                }else{
                                   mui.alert("提交失败")
                                }
                            },
                            error:function(xhr,type,errorThrown){
                             plus.nativeUI.closeWaiting()
                                alert("与大厅连接中断,请退出APP重新进入大厅唤醒")
                            },
                            complete :function(){
                                setTimeout(function(){
                                    plus.nativeUI.closeWaiting()
                                },500)
                            }
                        })
            },
            commint:function(item){
                var wat=plus.nativeUI.showWaiting('提交中...')
                mui.ajax('http://127.0.0.1:10261/itsm/rest/api/v2/itsm/tickets/progressing',{
                data:item,
                dataType:'json',
                type:'POST',
                timeout:12000,
                headers:{'Content-Type':'application/json'},
                success:function(data){

                    mui.back = function() {
                       var list = plus.webview.getWebviewById('commissionListview')||plus.webview.getLaunchWebview();
                        //触发列表界面的自定义事件（refresh）,从而进行数据刷新
                        //alert(JSON.stringify(list))
                        fd.delete('file')
                        fd.delete('objId')
                        fd.delete('field')
                       mui.fire(list,'refresh');
                       plus.webview.currentWebview().hide("auto", 300);
                       var self = plus.webview.currentWebview();
                       confirm()
                       self.addEventListener("hide",function (e) {
                           vm.guid='',
                           vm.author='',
                           vm.items=[],
                           vm.task=[]
                       },false);
                   }
                     if(data.success==true){
                        //alert(fd.has("file"))
                        if(fd.getAll("file").length>0){
                          //  alert("进入file")
                            this.id=data.id
                            fd.append("objId",vm.id)
                            fd.append("field",vm.field+vm.fieIdCode)
                           // alert(JSON.stringify(fd.getAll('file')))
                            //alert(JSON.stringify(this.id)+"--"+JSON.stringify(fd.get('file').name)+"--"+JSON.stringify(vm.field))
                            console.log(JSON.stringify(fd.get('file').name))
                            wat.setTitle("正在上传附件请稍后...")
                            mui.ajax('http://127.0.0.1:10261/itsm/rest/api/v2/itsm/tickets/upload',{
                                data:fd,
                                type:'post',
                                processData: false,
                                contentType: false,
                                success:function(data){
                                    var data=JSON.parse(data)
                                    //alert(JSON.stringify(data))
                                    if(data.success){
                                        mui.alert("附件上传成功")
                                        wat.close()
                                       mui.back()
                                    }else{
                                        mui.alert("附件上传失败")
                                        wat.close()
                                         mui.back()
                                    }
                                },
                                error:function(xhr,type,errorThrown){
                                    //异常处理；
                                    alert("与大厅连接中断,请退出APP重新进入大厅唤醒");
                                }
                            })
                        }else{
                        //alert("没有file")
                          wat.close()
                            plus.nativeUI.toast( "工单提交成功")
                            mui.back()
                        }

                    }else{
                         plus.nativeUI.toast( "工单提交失败");
                         wat.close()
                         mui.back()
                    }
                   // mui.back()
                       //plus.nativeUI.closeWaiting()
                     //  mui.back()
                },
                error:function(xhr,type,errorThrown){
                    //异常处理；
                    alert("与大厅连接中断,请退出APP重新进入大厅唤醒");
                }
            })
            },
            getTask: function(item){
                var obj={};
                var checkArr;
                var yjbzgl=false;
                objData.processId=this.id,
                objData.transitionId=item.id,
                objData.taskId=String(this.taskid),
                objData.creator=vm.getLogin,
                objData.bizObj={};
                var input=document.querySelectorAll('#form1 .text ')
                for(var i=0;i<input.length;i++){
                    objData.bizObj[input[i].name]=input[i].value
                }
                  var person=document.querySelectorAll('#form1 .person ')
                for(var i=0;i<person.length;i++){
                    objData.bizObj[person[i].name]=person[i].getAttribute('data-id')
                }
                var checked=document.querySelectorAll('#form1 .checked ')

                for(var i=0;i<checked.length;i++){
                    if(checked[i].checked){
                          if(objData.bizObj.hasOwnProperty(checked[i].name)){
                            objData.bizObj[checked[i].name] += ',' + checked[i].value;
                          }else{
                            objData.bizObj[checked[i].name] = checked[i].value;
                          }
                    }
                }

                var select=document.querySelectorAll('#form1 select ')
                for(var i=0;i<select.length;i++){
                    select[i].disabled=false
                     objData.bizObj[select[i].name]=select[i].value
                }
                var textare=document.querySelectorAll('#form1 textarea ')
                for(var i=0;i<textare.length;i++){
                     objData.bizObj[textare[i].name]=textare[i].value
                }
               var a = false;
               var b = false;

               mui("#form1 .validaTetable").each(function(i) {
                        a = true;
                        //若当前input为空，则alert提醒
                        console.log(i)
                        if(!this.value || this.value.trim() == "") {
                            var label = this.previousElementSibling;
                            mui.alert("必填项不允许为空");
                            checkArr = false;
                            return;
                        }else{
                            checkArr=true
                        }
               }); //校验通过，继续执行业务逻辑
                     var check = [];
                     var count = 0;
                    var v = document.querySelectorAll(".radiogroup");
                    for(var i=0,len=v.length;i<len;i++){
                       check[i] = v[i].querySelectorAll(".checked");
                        for(var j=0,length=check[i].length;j<length;j++){
                            if(check[i][j].checked==true){
                                count++;
                                b = true;
                            }
                        }
                    }
                    if(v.length==count||v.length<=count){
                        yjbzgl=true
                    }else{
                        mui.alert("必填项不允许为空");
                        yjbzgl=false;
                        return;
                    }
                    console.log(yjbzgl)
                    console.log(checkArr)

                    if(a && b){
                        if(yjbzgl&&checkArr){
                       // alert('都执行')
                           this.commintData(item);

                        }
                    }else if(a){
                       if(checkArr){
                        //alert('执行文本')
                               this.commintData(item)
                       }
                    }else if(b){
                        if(yjbzgl){
                         //alert('执行复选')
                                this.commintData(item)
                        }
                     }


                      //this.commintData()

                   /* function commintData(){
    if(this.author=='jjbgl'){
        if(item.name=='交班'){
            showone();
        }else{
            this.commint(objData)

        }
    }else{

        this.commint(objData)

     }
}*/
            },
            commintData:function(item){
                if(this.author=='jjbgl'){
                    if(item.name=='交班'){
                        showone();
                    }else{
                        this.commint(objData)
                    }
                }else{
                    this.commint(objData)
                 }
            },
            Download: function(obj){
                var path=obj.uri.replace(/http:\/\/11.55.0.81:8890/gi,'http:\/\/127.0.0.1:10261');
                var watiting=plus.nativeUI.showWaiting("下载中。。。请稍后");
                //alert(JSON.stringify(decodeURIComponent(path+"&encoding=UTF8")));
                var dtask = plus.downloader.createDownload(path+"&encoding=UTF8", {
                       method: 'get',
                       filename: '_downloads/'
                   }, function(d, status) {
                   if(status == 200) {
                        watiting.setTitle("下载成功"+ decodeURIComponent(d.filename))
                        plus.runtime.openFile( d.filename, {}, function ( e ) {//调用第三方应用打开文件
                            alert('打开失败');
                        })

                       setTimeout(function(){
                            watiting.close()
                       },2000)

                   } else {
                        watiting.setTitle("下载失败")
                        watiting.close()
                   }
                });
                           dtask.start();
            },
            Gareth:function(obj){
                this.fj=obj.bizField
                mui('#popover').popover('show');
            },
            onUploadChange(e){
                 var form = document.getElementById("form2");
                for(var i=0;i<e.target.files.length;i++){
                   // this.fileArray.push(e.target.files[0])
                    fd.append('file',e.target.files[0])
                    var p=document.createElement('p')
                    /*var span=document.createElement('span')
                    span.className='mui-icon mui-icon-close remove';
                    span.style.position='absolute';
                    span.style.top=0+'px';
                    span.style.right=0+'px';
                    span.style.color='red';*/
                    p.className=" form-control doenload";
                    p.style.marginBottom=15+'px';
                    p.style.position='relative';
                    p.innerHTML=e.target.files[0].name;
                    e.target.parentNode.parentNode.appendChild(p);
                    document.querySelectorAll('.mui-btn.mui-btn-danger')[0].style.display='block';
                    //p.appendChild(span)
                //console.log(JSON.stringify(fd.get('file').name)+'--'+JSON.stringify(fd.get('objId')))
                }
               /* var form = document.getElementById("form2");
                var fd = new FormData(form);
                fd.append("objId",vm.id)
                fd.append("field",vm.field)
                fd.append("file",e.target.files[0])
                var watiting=plus.nativeUI.showWaiting("上传中...请稍后");
                mui.ajax('http://127.0.0.1:10261/itsm/rest/api/v2/itsm/tickets/upload',{
                    data:fd,
                    type:'post',
                    processData: false,
                    contentType: false,
                    success:function(data){
                        var data=JSON.parse(data)
                        alert(typeof data.success)
                        if(data.success){
                            mui.alert("上传成功")
                            watiting.close()
                            alert(vm.id)
                            getAjax()
                        }else{
                            mui.alert("上传失败")
                            watiting.close()
                        }
                    },
                    error:function(xhr,type,errorThrown){
                        //异常处理；
                        alert(2332);
                    }
                })*/
            },
             remove(e){
                        var p=e.target.parentNode.parentNode.querySelectorAll('p')
                        console.log(e.target.parentNode.parentNode.querySelectorAll('p'))
                        for (var i = 0; i<p.length; i++){
                            e.target.parentNode.parentNode.removeChild(p[i])
                        }
                        fd.delete('file')
                        //alert(JSON.stringify(fd.getAll('file')))
                        e.target.style.display='none'
                     },
            test(){
                alert()
                 plus.runtime.openFile( "/1.png",{},function(e){
                        alert(e)
                 } )
                /* plus.io.requestFileSystem(plus.io.PUBLIC_DOWNLOADS, function( fs ) {
                        // 可通过fs操作PRIVATE_WWW文件系统

                          var directoryReader = fs.root.createReader();
                                 directoryReader.readEntries( function( entries )  //遍历该文件夹下的文件
                                          {
                                     var i;
                                     for( i=0; i < entries.length; i++ )
                                                  {
                                         alert( entries[i].name );  //获得文件名称

                                     }

                                 }, function ( e )
                                           {
                                     alert( "Read entries failed: " + e.message );
                                 } );
                    }, function ( e ) {
                        alert( "Request file system failed: " + e.message );
                    })*/
            }
        }
    })

mui.plusReady(function(){
    window.addEventListener('get_detail',function(event){
        vm.guid=event.detail.guid;
        vm.id=event.detail.id
        vm.author=event.detail.author;
        vm.field=event.detail.field;
        vm.getLogin=event.detail.getLogin

        plus.nativeUI.showWaiting( '正在加载' )
       getAjax()
    })
    function getAjax(){
        mui.ajax("http://127.0.0.1:10261/itsm/rest/api/v2/itsm/tickets/queryByForm?userId="+vm.getLogin+"&processId="+vm.id,{
            dataType:'json',
            type:'get',
            success:function(res){

                //alert(JSON.stringify(res))

          /* var res={
                     "result": {
                       "success": true
                     },
                     "ticket": {
                       "id": "a05c95b6-9831-43fa-acde-f81ec5a16239",
                       "data": [
                         {
                           "id": "c3fbe75b-bb1c-414c-9cc4-32c1fe77f01a",
                           "row": 1,
                           "col": 1,
                           "title": "业务咨询",
                           "type": "group",
                           "item": [
                             {
                               "id": "187366bd-9a0d-4d66-8126-15cc990c3bf2",
                               "row": 1,
                               "col": 1,
                               "type": "group",
                               "item": [
                                 {
                                   "id": "5756ec72-c4c5-4b50-9466-ce04b96014d2",
                                   "row": 1,
                                   "col": 1,
                                   "title": "保障中心记录人",
                                   "bizClass": "zxbd",
                                   "bizField": "bzzxjlr",
                                   "displayType": "required",
                                   "readonly": "false",
                                   "type": "element",
                                   "bzType": "userSelect",
                                   "value": {
                                     "id": "bf47ef47-4b4e-4d79-abe1-73cb91bce93c",
                                     "name": "肖海峰",
                                     "dept": "加格达奇输油气分公司",
                                     "email": "hfxiao@petrochina.com.cn",
                                     "mobile": "18704570808"
                                   }
                                 }
                               ]
                             },
                             {
                               "id": "a334021d-fccc-4903-86d2-46575370f8a3",
                               "row": 2,
                               "col": 1,
                               "type": "group",
                               "item": [
                                 {
                                   "id": "2529a996-69e0-4004-8ea4-b1a3ec58b0c5",
                                   "row": 1,
                                   "col": 1,
                                   "title": "记录时间",
                                   "bizClass": "zxbd",
                                   "bizField": "jlsj1",
                                   "displayType": "required",
                                   "readonly": "false",
                                   "type": "element",
                                   "bzType": "date",
                                   "value": "2018-04-18 16:27",
                                   "dataType": "Date",
                                   "dataFormat": "yyyy-MM-dd HH:mm"
                                 }
                               ]
                             },
                             {
                               "id": "7dc2911a-d422-48dd-8ac7-504d28b8a4d7",
                               "row": 3,
                               "col": 1,
                               "type": "group",
                               "item": [
                                 {
                                   "id": "128dd412-3c4c-4595-9c82-a4a508d16700",
                                   "row": 1,
                                   "col": 1,
                                   "title": "咨询单位",
                                   "bizClass": "zxbd",
                                   "bizField": "zxdw1",
                                   "displayType": "required",
                                   "readonly": "false",
                                   "type": "element",
                                   "bzType": "text",
                                   "value": "显卡"
                                 },
                                 {
                                   "id": "1ff8db87-78ec-4fe2-9653-4347c9c81974",
                                   "row": 1,
                                   "col": 2,
                                   "title": "咨询人员",
                                   "bizClass": "zxbd",
                                   "bizField": "zxry1",
                                   "displayType": "required",
                                   "readonly": "false",
                                   "type": "element",
                                   "bzType": "text",
                                   "value": "显卡"
                                 }
                               ]
                             },
                             {
                               "id": "b1765114-af6d-46db-a06a-91765683da40",
                               "row": 4,
                               "col": 1,
                               "type": "group",
                               "item": [
                                 {
                                   "id": "2e07e28e-da8b-41e7-9c2a-3ad49502360b",
                                   "row": 1,
                                   "col": 1,
                                   "title": "咨询时间",
                                   "bizClass": "zxbd",
                                   "bizField": "zusj1",
                                   "displayType": "required",
                                   "readonly": "false",
                                   "type": "element",
                                   "bzType": "date",
                                   "value": "2018-03-18 16:27",
                                   "dataType": "Date",
                                   "dataFormat": "yyyy-MM-dd HH:mm"
                                 }
                               ]
                             },
                             {
                               "id": "698e1c41-223a-4829-97c2-c6ffea565e26",
                               "row": 5,
                               "col": 1,
                               "type": "group",
                               "item": [
                                 {
                                   "id": "3ba0ead3-cf51-4cdc-a4ff-a22dfd1e85ed",
                                   "row": 1,
                                   "col": 1,
                                   "title": "咨询方式",
                                   "bizClass": "zxbd",
                                   "bizField": "zxfs",
                                   "displayType": "required",
                                   "readonly": "false",
                                   "type": "element",
                                   "bzType": "select",
                                   "defaultValue": "1$^$电话$?$2$^$QQ/微信/E-mail$?$3$^$日常测试$?$4$^$其他",
                                   "value": "QQ/微信/E-mail"
                                 },
                                 {
                                   "id": "338bf285-1797-44bb-86c9-f37118a6185c",
                                   "row": 2,
                                   "col": 1,
                                   "title": "业务咨询类别",
                                   "bizClass": "zxbd",
                                   "bizField": "ywzxlb",
                                   "displayType": "required",
                                   "readonly": "false",
                                   "type": "element",
                                   "bzType": "select",
                                   "defaultValue": "1$^$制度管理类$?$2$^$人员管理类$?$3$^$日常运维类$?$4$^$通信保障类$?$5$^$演练测试类$?$6$^$安全保密类$?$7$^$文件报表类$?$8$^$培训考核类$?$9$^$其它类",
                                   "value": "制度管理类"
                                 },
                                 {
                                   "id": "173284c3-1404-45de-b369-cdb5f330ab43",
                                   "row": 3,
                                   "col": 1,
                                   "title": "咨询内容描述",
                                   "bizClass": "zxbd",
                                   "bizField": "zxnrms",
                                   "displayType": "required",
                                   "readonly": "false",
                                   "type": "element",
                                   "bzType": "textarea",
                                   "value": "项目"
                                 },
                                 {
                                   "id": "f1b7a37c-564d-4352-9fe2-279604f0a057",
                                   "row": 4,
                                   "col": 1,
                                   "title": "附件",
                                   "bizClass": "zxbd",
                                   "bizField": "fj",
                                   "displayType": "opitonal",
                                   "readonly": "false",
                                   "type": "element",
                                   "bzType": "attachFile",
                                   "value": []
                                 }
                               ]
                             },
                             {
                               "id": "40746b15-f51a-461d-ab94-b22509c8a201",
                               "row": 6,
                               "col": 1,
                               "type": "group",
                               "item": [
                                 {
                                   "id": "094cb65c-ce45-4ff4-b87c-404dfe47c06e",
                                   "row": 1,
                                   "col": 1,
                                   "title": "处理结果",
                                   "bizClass": "zxbd",
                                   "bizField": "cljg",
                                   "displayType": "required",
                                   "readonly": "false",
                                   "type": "element",
                                   "bzType": "radiogroup",
                                   "defaultValue": "1$^$已完成$?$2$^$任务改派",
                                   "value": "1",
                                   "dispValue": "已完成"
                                 }
                               ]
                             },
                             {
                               "id": "b06fa0fb-e099-46f6-9df4-52a4d91dcb1d",
                               "row": 7,
                               "col": 1,
                               "type": "group",
                               "item": [
                                 {
                                   "id": "e6dc42d6-292c-4217-9f7d-a79c65c2eb7c",
                                   "row": 1,
                                   "col": 1,
                                   "title": "改派人",
                                   "bizClass": "zxbd",
                                   "bizField": "gpr",
                                   "displayType": "opitonal",
                                   "readonly": "false",
                                   "type": "element",
                                   "bzType": "text"
                                 }
                               ]
                             },
                             {
                               "id": "3b9c48f6-0824-4c36-bf19-0d49a37877b2",
                               "row": 8,
                               "col": 1,
                               "type": "group",
                               "item": [
                                 {
                                   "id": "760df5d3-d206-4a26-b6a8-77499215a104",
                                   "row": 1,
                                   "col": 1,
                                   "title": "处理内容及结果",
                                   "bizClass": "zxbd",
                                   "bizField": "gphcljg",
                                   "displayType": "opitonal",
                                   "readonly": "false",
                                   "type": "element",
                                   "bzType": "textarea"
                                 }
                               ]
                             }
                           ]
                         },
                         {
                           "id": "cbf4c119-8a57-42c5-910f-308cb1b06b49",
                           "row": 2,
                           "col": 1,
                           "title": "流程信息",
                           "type": "group",
                           "item": [
                             {
                               "id": "22b15af4-13f0-4e91-8a17-8604089d2ba6",
                               "row": 1,
                               "col": 1,
                               "type": "group",
                               "item": [
                                 {
                                   "id": "310b06b1-2fec-4155-9c57-ad9d3e470397",
                                   "row": 1,
                                   "col": 1,
                                   "title": "流程记录",
                                   "bizClass": "processObject",
                                   "bizField": "processRecord",
                                   "displayType": "readonly",
                                   "readonly": "true",
                                   "type": "element"
                                 }
                               ]
                             }
                           ]
                         }
                       ]
                     },
                     "task": [
                       {
                         "id": 46105,
                         "name": "咨询工单填写",
                         "action": [
                           {
                             "id": "Link_3",
                             "name": "保存"
                           },
                           {
                             "id": "Link_0",
                             "name": "关闭"
                           }
                         ],
                         "claim": false
                       }
                     ]
                   }*/
            if(res.message=='工单查询出错 null'){
                mui.alert('数据有误，请返回')
                 plus.nativeUI.closeWaiting()

            }
            var ob=[]
            var n=res.ticket.data
            for(var obj in n){
                if(n[obj].hasOwnProperty('item')&& Array.isArray(n[obj].item)){
                    ob.push(Recursion(n[obj]))
                }
            }
            function Recursion(item){
                var m = [];
                for(var i in item.item){
                    if(item.item[i].hasOwnProperty('item') && Array.isArray(item.item[i].item)){
                        m.push(Recursion(item.item[i]))
                    }else{
                        if(item.item[i].title!==undefined){
                            if(item.item[i].value===undefined){
                                item.item[i].value=""
                            }
                            m.push({
                            id: item.item[i].id,
                            title: item.item[i].title,
                            value: item.item[i].value,
                            bizClass:item.item[i].bizClass,
                            bizField:item.item[i].bizField,
                            bzType:item.item[i].bzType,
                            displayType:item.item[i].displayType,
                            defaultValue:item.item[i].defaultValue
                        })
                        }
                    }
                }
                return m;
            }
            var t = [];
           function tran(n){
                for(var i in n){
                    if(Array.isArray(n[i])){
                        tran(n[i])
                    }else{
                        t.push(n[i])
                    }
                }
           }
        tran(ob)
        String.prototype.endWith=function(endStr){
              var d=this.length-endStr.length;
              return (d>=0&&this.lastIndexOf(endStr)==d)
            }
        function GetChinese(strValue,sValue) {
            console.log("=="+sValue+"==");
            if(strValue!= null && strValue!= ""){
                //var reg = /[\u4e00-\u9fa5]/g;
                var return_strs = new Array();
                var strs = new Array();
                strs = strValue.split('$?$');
                for(var i = 0; i < strs.length; i ++){
                    var st = new Array();
                    st = strs[i].split('$^$');
                    var re_str ;
                    console.log("=="+st[0]+"==");
                    if(st[0].endWith(":default")){
                        if(contains(sValue, st[0].trim().substring(0,(st[0].length - 8)))){
                            re_str = '{"value" : "' + st[0].substring(0,(st[0].length - 8)) + '","name" : "' + st[1] + '","default" : true,"selected" : true}';
                        }else{
                            re_str = '{"value" : "' + st[0].substring(0,(st[0].length - 8)) + '","name" : "' + st[1] + '","default" : true,"selected" : false}';
                        }
                    }else{
                        if(contains(sValue, st[0].trim())){
                            re_str = '{"value" : "' + st[0] + '","name" : "' + st[1] + '","default" : false,"selected" : true}';
                        }else{
                            re_str = '{"value" : "' + st[0] + '","name" : "' + st[1] + '","default" : false,"selected" : false}';
                        }

                    }
                    re_str = eval('(' + re_str + ')');
                    //console.log(re_str);
                    return_strs.push(re_str);
                }
                //console.log(strs);
                return return_strs;
            }
            else
                return "";
        }

        for(var n in t){

            if(t[n].value != undefined && t[n].value != "" && t[n].value != null){
                if(typeof(t[n].value) == 'string'){
                    /*if((t[n].value).indexOf('$?$') >= 0){
                        var strs = new Array();
                        strs = (t[n].value).split('$?$');
                        var return_strs = new Array();
                        for(var i = 1; i < strs.length; i++){
                            return_strs.push(strs[i].trim());
                        }
                        t[n].value = return_strs;
                    }
                    if((t[n].value).indexOf(',') >= 0){
                        var strs = new Array();
                        strs = (t[n].value).split(',');
                        var return_strs = new Array();
                        for(var i = 0; i < strs.length; i++){
                            return_strs.push(strs[i].trim());
                        }
                        t[n].value = return_strs;
                    }*/
                    if(t[n].bzType=='checkbox'){
                        if((t[n].value).indexOf('$?$') >= 0){
                            var strs = new Array();
                            strs = (t[n].value).split('$?$');
                            var return_strs = new Array();
                            for(var i = 1; i < strs.length; i++){
                                return_strs.push(strs[i].trim());
                            }
                            t[n].value = return_strs;
                        }else if((t[n].value).indexOf(',') >= 0){
                            var strs = new Array();
                            strs = (t[n].value).split(',')||t[n].value;
                            var return_strs = new Array();
                            for(var i = 0; i < strs.length; i++){
                                return_strs.push(strs[i].trim());
                            }
                            t[n].value = return_strs;

                        }else{
                            var str=new Array()
                            str.push(t[n].value)
                            t[n].value=str
                            console.log(t[n].value)
                        }


                    }else{

                            if((t[n].value).indexOf('$?$') >= 0){
                                var strs = new Array();
                                strs = (t[n].value).split('$?$');
                                var return_strs = new Array();
                                for(var i = 1; i < strs.length; i++){
                                    return_strs.push(strs[i].trim());
                                }
                                t[n].value = return_strs;
                        }
                        if((t[n].value).indexOf(',') >= 0){
                            var strs = new Array();
                            strs = (t[n].value).split(',')||t[n].value;
                            var return_strs = new Array();
                            for(var i = 0; i < strs.length; i++){
                                return_strs.push(strs[i].trim());
                            }
                            t[n].value = return_strs;
                        }


                    }

                }
            }

            if(t[n].defaultValue!=undefined){
                t[n].defaultValue = GetChinese(t[n].defaultValue,t[n].value);
            }

        }
    function contains(arr, obj) {
      var i = arr.length;
      while (i--) {
        if (arr[i] === obj) {
          return true;
        }
      }
      return false;
    }
    vm.items=t
    console.log(vm.items)
    for(var i=0;i<vm.items.length;i++){
        if(vm.items[i].title.indexOf("附件")>=0){
               vm.fieIdCode=vm.items[i].bizField
        }
    }

    var task=res.task[0];
        if(task.claim!=undefined){
             vm.claim=task.claim
        }else{
            vm.claim=false
        }

    //alert(vm.claim)

    for(var n in task.action){
        vm.task.push(task.action[n])
        if(task.action[n].hasOwnProperty("performer")&&Array.isArray(task.action[n].performer)&&task.action[n].name==='交班'){
            for(var j in task.action[n].performer){
                vm.performer.push({
                    text:task.action[n].performer[j].name,
                    id:task.action[n].performer[j].id,
                    account:task.action[n].performer[j].iaccount,
                    orgId:task.action[n].performer[j].orgId,
                    deptId:task.action[n].performer[j].deptId,
                })
                console.log(task.action[n].performer[j])
            }
        }
    }
       // alert(JSON.stringify(vm.performer))

        vm.taskid=task.id

            },
            error:function(xhr,type,errorThrown){
             plus.nativeUI.closeWaiting()
                alert("与大厅连接中断,请退出APP重新进入大厅唤醒")
            },
            complete :function(){
                setTimeout(function(){
                    plus.nativeUI.closeWaiting()
                },500)
            }
        })
        mui.back = function() {
                   plus.webview.currentWebview().hide("auto", 300);
                   fd.delete('file')
                      fd.delete('objId')
                      fd.delete('field')
                   var self = plus.webview.currentWebview();
                   close()
                   closeOne()
                   self.addEventListener("hide",function (e) {
                       vm.guid='',
                       vm.author='',
                       vm.items=[],
                       vm.task=[]
                   },false);
               }
    }

      getPerson('danwei','bumen','jianchar');
      getPersonOne('danweione','bumenone','jiancharone');
function getPerson(obj,bumen,jianchar){
    var showUserPickerButton = document.getElementById(obj);
    showUserPickerButton.addEventListener('tap', function(event) {
        var evt=event ||window.event
        evt.stopPropagation()
        document.getElementById('bumen').value=""
        document.getElementById('jianchar').value=""
        var userPicker = new mui.PopPicker();
        mui.ajax("http://127.0.0.1:10261/itsm/rest/api/v2/acm/user/org",{
            dataType:'json',
            type:'get',
            success:function(res){
                var ni=[]
                for(var n in res.data){
                    ni.push({
                        text:res.data[n].name,
                        id:res.data[n].id
                    })
                }
                userPicker.setData(ni);
                userPicker.show(function(items) {
                    showUserPickerButton.value = items[0].text;
                    document.getElementById('danwei').setAttribute('data',items[0].id)
                    //返回 false 可以阻止选择框的关闭
                    //return false;
                    userPicker.dispose()
                });
            },
            error:function(xhr,type,errorThrown){
                plus.nativeUI.closeWaiting();
                alert("与大厅连接中断,请退出APP重新进入大厅唤醒")
            }
        })
    }, false);
    var bumen = document.getElementById(bumen);
    var danwei =showUserPickerButton// document.getElementById('danwei');
    bumen.addEventListener('tap', function(event) {
    var evt=event ||window.event
    evt.stopPropagation()
    document.getElementById('jianchar').value=""
        var user = new mui.PopPicker();
        if(danwei.getAttribute('data')==null){
                return false;
        }else{
             mui.ajax("http://127.0.0.1:10261/itsm/rest/api/v2/acm/user/dept?orgId="+danwei.getAttribute('data'),{
                dataType:'json',
                type:'get',
                success:function(res){
                    var ni=[]
                    for(var n in res.data){
                        ni.push({
                            text:res.data[n].name,
                            id:res.data[n].id
                        })
                    }
                    user.setData(ni);
                },
                error:function(xhr,type,errorThrown){
                    plus.nativeUI.closeWaiting();
                    alert("与大厅连接中断,请退出APP重新进入大厅唤醒")
                }
            })
             user.show(function(items) {
                    bumen.value = items[0].text;
                    document.getElementById('bumen').setAttribute('data',items[0].id)
                    //返回 false 可以阻止选择框的关闭
                    //return false;
                    user.dispose()
                });
        }
    }, false);
    var jianchar = document.getElementById(jianchar);
    jianchar.addEventListener('tap', function(event) {
    var evt=event ||window.event
        evt.stopPropagation()
        var user = new mui.PopPicker();
        if(bumen.getAttribute('data')==null){
                return false;
        }else{
            mui.ajax("http://127.0.0.1:10261/itsm/rest/api/v2/acm/user/?deptId="+bumen.getAttribute('data'),{
                dataType:'json',
                type:'get',
                success:function(res){
                    var ni=[]
                    for(var n in res.data){
                        ni.push({
                            text:res.data[n].name,
                            id:res.data[n].id
                        })
                    }
                    user.setData(ni);
                },
                error:function(xhr,type,errorThrown){
                    plus.nativeUI.closeWaiting();
                    alert("与大厅连接中断,请退出APP重新进入大厅唤醒")
                }
            })
            user.show(function(items) {
                jianchar.value = items[0].text;
                document.getElementById('jianchar').setAttribute('data',items[0].id)
                //返回 false 可以阻止选择框的关闭
                //return false;
                user.dispose()
            });
        }
    }, false);
}
function getPersonOne(obj,bumen,jianchar){
     var showUserPickerButton = document.getElementById(obj);
     showUserPickerButton.addEventListener('tap', function(event) {
         var evt=event ||window.event
         evt.stopPropagation()
         document.getElementById('bumenone').value=""
         document.getElementById('jiancharone').value=""
         var userPicker = new mui.PopPicker();
         mui.ajax("http://127.0.0.1:10261/itsm/rest/api/v2/acm/user/org",{
             dataType:'json',
             type:'get',
             success:function(res){
                 var ni=[]
                 for(var n in res.data){
                     ni.push({
                         text:res.data[n].name,
                         id:res.data[n].id
                     })
                 }
                 userPicker.setData(ni);
                 userPicker.show(function(items) {
                     showUserPickerButton.value = items[0].text;
                     document.getElementById('danweione').setAttribute('data',items[0].id)
                     //返回 false 可以阻止选择框的关闭
                     //return false;
                     userPicker.dispose()
                 });
             },
             error:function(xhr,type,errorThrown){
                 plus.nativeUI.closeWaiting();
                 alert("与大厅连接中断,请退出APP重新进入大厅唤醒")
             }
         })
     }, false);
     var bumen = document.getElementById(bumen);
     var danwei =document.getElementById('danweione');
     bumen.addEventListener('tap', function(event) {
     var evt=event ||window.event
     evt.stopPropagation()
     document.getElementById('jiancharone').value=""
         var user = new mui.PopPicker();
         if(danwei.getAttribute('data')==null){
                 return false;
         }else{
              mui.ajax("http://127.0.0.1:10261/itsm/rest/api/v2/acm/user/dept?orgId="+danwei.getAttribute('data'),{
                 dataType:'json',
                 type:'get',
                 success:function(res){
                     var ni=[]
                     for(var n in res.data){
                         ni.push({
                             text:res.data[n].name,
                             id:res.data[n].id
                         })
                     }
                     user.setData(ni);
                 },
                 error:function(xhr,type,errorThrown){
                     plus.nativeUI.closeWaiting();
                     alert("与大厅连接中断,请退出APP重新进入大厅唤醒")
                 }
             })
              user.show(function(items) {
                     bumen.value = items[0].text;
                     document.getElementById('bumenone').setAttribute('data',items[0].id)
                     //返回 false 可以阻止选择框的关闭
                     //return false;
                     user.dispose()
                 });
         }
     }, false);
     var jianchar = document.getElementById(jianchar);
     jianchar.addEventListener('tap', function(event) {
     var evt=event ||window.event
         evt.stopPropagation()
         var user = new mui.PopPicker();
         if(bumen.getAttribute('data')==null){
                 return false;
         }else{
             mui.ajax("http://127.0.0.1:10261/itsm/rest/api/v2/acm/user/?deptId="+bumen.getAttribute('data'),{
                 dataType:'json',
                 type:'get',
                 success:function(res){
                     var ni=[]
                     for(var n in res.data){
                         ni.push({
                             text:res.data[n].name,
                             id:res.data[n].id
                         })
                     }
                     user.setData(ni);
                 },
                 error:function(xhr,type,errorThrown){
                     plus.nativeUI.closeWaiting();
                     alert("与大厅连接中断,请退出APP重新进入大厅唤醒")
                 }
             })
             user.show(function(items) {
                 if(items[0].text==undefined){
                    jianchar.value = ''
                }else{
                jianchar.value = items[0].text;
                }
                // jianchar.value = items[0].text;
                 document.getElementById('jiancharone').setAttribute('data',items[0].id)
                 //返回 false 可以阻止选择框的关闭
                 //return false;
                 user.dispose()
             });
         }
     }, false);
 }

    })
/*function Gareth(){
    mui('#popover').popover('show');
}*/


// 从相册中选择多张图片
function galleryImgs(){
	// 从相册中选择图片

	console.log("从相册中选择多张图片:");

    plus.gallery.pick( function(path){
    var task = plus.uploader.createUpload( "http://127.0.0.1:10261/itsm/rest/api/v2/itsm/tickets/upload",
    		{ method:"POST" },
    		function ( t, status ) {
    			if ( status == 200 ) {
    				alert(JSON.stringify(status))
                    alert(JSON.stringify(t))
    			} else {
    				alert(JSON.stringify(status+'1'))
                  alert(JSON.stringify(t+'1'))
    			}
    		}
    	);
    	task.addFile(path, {key:"fj"} );
    	//task.addData( "name", "string_value" );
    	task.addData("objId",vm.id)
         task.addData("field",vm.field)
task.start();


    	mui('#popover').popover('hide');
    }, function ( e ) {
    	alert( "取消选择图片" );
    	mui('#popover').popover('hide');
    },{system:true});
}


// 拍照
function getImage(){
	var cmr = plus.camera.getCamera();
	cmr.captureImage(function(path){
		plus.gallery.save(path, function(){
			console.log("file://"+plus.io.convertLocalFileSystemURL(path))
			mui('#popover').popover('hide');
		}, function(e){
			console.log('保存失败: '+JSON.stringify(e))
			mui('#popover').popover('hide');
		});
	}, function(e){
		console.log('取消拍照')
		mui('#popover').popover('hide');
	}, {filename:'_doc/gallery/',index:1});
}

// 录像
function getVideo(){
	var cmr = plus.camera.getCamera();
	cmr.startVideoCapture(function(path){
		console.log("file://"+plus.io.convertLocalFileSystemURL(path))
		mui('#popover').popover('hide');
	}, function(e){
		console.log(e.Message)
			mui('#popover').popover('hide');
	}, {filename:'_doc/camera/',index:1});
}


function close(){
    document.getElementById('mui-backdrop').style.display='none';
    document.getElementById('bumen').value="";
    document.getElementById('jianchar').value="";
    document.getElementById('danwei').value="";
}
function closeOne(){
    document.getElementById('mui-backdropone').style.display='none';
        document.getElementById('bumenone').value="";
        document.getElementById('jiancharone').value="";
        document.getElementById('danweione').value="";
}
function show(){
    document.getElementById('mui-backdrop').style.display='block';
}
function showone(){
    document.getElementById('mui-backdropone').style.display='block';
}
function confirm(){
    if(document.getElementById('jianchar').value==""){
        return false
    }else{
        document.querySelector('.obj').value=document.getElementById('jianchar').value
        document.querySelector('.obj').setAttribute('data-id',document.getElementById('jianchar').getAttribute('data'))
        document.getElementById('mui-backdrop').style.display='none';
        document.getElementById('bumen').value="";
        document.getElementById('jianchar').value="";
        document.getElementById('danwei').value="";
    }

}
function confirmone(){
    if(document.getElementById('jiancharone').value==""){
        return false
    }else{
        document.getElementById('mui-backdropone').style.display='none';
        objData.allocated=document.getElementById('jiancharone').getAttribute('data')
        document.getElementById('bumenone').value="";
        document.getElementById('jiancharone').value="";
        document.getElementById('danweione').value="";
        //alert(JSON.stringify(objData))
          mui.ajax('http://127.0.0.1:10261/itsm/rest/api/v2/itsm/tickets/progressing',{
            data:objData,
            dataType:'json',
            type:'post',
            headers:{'Content-Type':'application/json'},
            success:function(data){
                //alert(JSON.stringify(data))
               // mui.back()
               mui.back = function() {
                       var list = plus.webview.getWebviewById('commissionListview')||plus.webview.getLaunchWebview();
                   //触发列表界面的自定义事件（refresh）,从而进行数据刷新
                  // alert(JSON.stringify(list))
                       mui.fire(list,'refresh');
                       plus.webview.currentWebview().hide("auto", 300);
                       var self = plus.webview.currentWebview();
                       confirm()
                       self.addEventListener("hide",function (e) {
                           vm.guid='',
                           vm.author='',
                           vm.items=[],
                           vm.task=[]
                       },false);
                   }
                   plus.nativeUI.closeWaiting()
                   mui.back()
            },
            error:function(xhr,type,errorThrown){
                //异常处理；
                alert("与大厅连接中断,请退出APP重新进入大厅唤醒");
            }
        })
    }

}
